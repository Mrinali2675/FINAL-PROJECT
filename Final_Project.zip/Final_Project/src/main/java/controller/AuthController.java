package controller;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/login")
	public String login(@RequestBody User user) {
		Optional<User> found = userRepository.findByUsername(user.getUsername());
		if (found.isPresent() && found.get().getPassword().equals(user.getPassword())) {
			return "Login successful!";
		}
		return "Invalid credentials!";
	}

	@PostMapping("/register")
	public User register(@RequestBody User user) {
		return userRepository.save(user);
	}
}