package com.example.demo.repository;

import java.util.Optional;

import com.example.demo.model.User;

public class UserRepository {

	public Optional<User> findByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	public User save(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
